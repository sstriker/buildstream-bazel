#define DATA_GEN 7
