int gen_value(void) { return 42; }
