#include "gen.h"
int gen_value(void){return 7;}
