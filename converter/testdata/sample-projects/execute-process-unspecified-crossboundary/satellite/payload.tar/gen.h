int gen_value(void);
